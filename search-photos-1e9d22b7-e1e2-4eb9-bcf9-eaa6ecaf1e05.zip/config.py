ALLOWED_CATEGORIES = ['cat', 'dog', 'monkey', 'bird', 'tree']
TABLE_NAME = 'your-table-name',
INDEX_NAME = 'some-index',